package ua.dnepr.valera.crypto.position_tracker;

import com.binance.fapi.client.constant.BinanceApiConstants;
import com.binance.fapi.client.domain.account.NewOrder;
import com.binance.fapi.client.domain.account.Order;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class OrdersHolder {

    private NewOrder clientOrder;
    private Order serverOrder;

    private boolean cancelled = false;
    private boolean executed = false;
    private String entryPrice = "0";

    public boolean isCancelledOrExecuted() {
        return cancelled || executed;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setExecuted(boolean executed) {
        this.executed = executed;
    }

    public boolean isExecuted() {
        return executed;
    }

    public OrdersHolder(NewOrder clientOrder, String entryPrice) {
        this.clientOrder = clientOrder;
        this.entryPrice = entryPrice;
    }

    public OrdersHolder(NewOrder clientOrder, Order serverOrder) {
        this.clientOrder = clientOrder;
        this.serverOrder = serverOrder;
    }

    public NewOrder getClientOrder() {
        return clientOrder;
    }

    public void setClientOrder(NewOrder clientOrder) {
        this.clientOrder = clientOrder;
    }

    public Order getServerOrder() {
        return serverOrder;
    }

    public void setServerOrder(Order serverOrder) {
        this.serverOrder = serverOrder;
    }

    public String getEntryPrice() {
        return entryPrice;
    }

    public void setEntryPrice(String entryPrice) {
        this.entryPrice = entryPrice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, BinanceApiConstants.TO_STRING_BUILDER_STYLE)
                .append(" clientOrder", clientOrder)
                .append(" serverOrder", serverOrder)
                .append(" executed", executed)
                .append(" cancelled", cancelled)

                .toString();
    }

}
