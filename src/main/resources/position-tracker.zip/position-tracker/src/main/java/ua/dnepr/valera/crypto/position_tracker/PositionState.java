package ua.dnepr.valera.crypto.position_tracker;

import com.binance.fapi.client.domain.OrderStatus;
import com.binance.fapi.client.domain.account.NewOrder;
import com.binance.fapi.client.domain.account.Order;
import com.binance.fapi.client.domain.account.ServerOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PositionState {

    private String amount = "0.000";
    private String entryPrice = "0.00000"; // 0.00000

    private List<OrdersHolder> orders = new ArrayList<>();


    public boolean isOpen() {
        return new BigDecimal(amount).abs().compareTo(BigDecimal.ZERO) > 0;
    }

    public PositionSide getSide() {
        return new BigDecimal(amount).signum() == 0 ? null : (new BigDecimal(amount).signum() == 1 ? PositionSide.LONG : PositionSide.SHORT);
    }

    public void setOrders(List<NewOrder> clientOrders) {
        orders.clear();

        for (NewOrder clientOrder : clientOrders) {
            orders.add(new OrdersHolder(clientOrder, this.entryPrice));
        }
    }

    public void addOrders(List<NewOrder> clientOrders) {
        for (NewOrder clientOrder : clientOrders) {
            orders.add(new OrdersHolder(clientOrder, this.entryPrice));
        }
    }

    public void setServerOrders(List<ServerOrder> serverOrders) {
        orders.clear();

        for (ServerOrder serverOrder : serverOrders) {
            // TODO decide which orders will be handled by App ( what about externally created ? stops? )
            NewOrder clientOrder = new NewOrder(serverOrder.getSymbol(), serverOrder.getSide(),serverOrder.getType(), serverOrder.getTimeInForce(), serverOrder.getOriginalQuantity(), serverOrder.getPrice());
            clientOrder.setNewClientOrderId(serverOrder.getClientOrderId());
            clientOrder.setNewClientOrderIdLabel(serverOrder.getClientOrderId().lastIndexOf("-") != -1 ? serverOrder.getClientOrderId().substring(0, serverOrder.getClientOrderId().lastIndexOf("-")) : serverOrder.getClientOrderId());

            Order order = new Order();
            order.setSymbol(serverOrder.getSymbol());
            order.setOrderId(serverOrder.getOrderId());
            order.setClientOrderId(serverOrder.getClientOrderId());
            order.setPrice(serverOrder.getPrice());
            order.setReduceOnly(serverOrder.getReduceOnly());
            order.setOriginalQuantity(serverOrder.getOriginalQuantity());
            order.setAccumulatedQuantity(serverOrder.getAccumulatedQuantity());
            order.setOrderStatus(serverOrder.getOrderStatus());
            order.setTimeInForce(serverOrder.getTimeInForce());
            order.setType(serverOrder.getType());
            order.setSide(serverOrder.getSide());
            order.setStopPrice(serverOrder.getStopPrice());
            order.setTradeTime(serverOrder.getUpdateTime());
            orders.add(new OrdersHolder(clientOrder, order));
        }
    }

//    public List<OrdersHolder> getOrdersSortedByPrice() {
//        Collections.sort(orders, new Comparator<OrdersHolder>() {
//            @Override
//            public int compare(OrdersHolder o1, OrdersHolder o2) {
//                return o1.getClientOrder().getPrice().compareTo(o2.getClientOrder().getPrice());
//            }
//        });
//
//        return orders;
//    }

    public List<OrdersHolder> getOrdersSortedReversal() {
        ArrayList<OrdersHolder> sortedReversal = new ArrayList<>(orders);
        Collections.sort(sortedReversal, new Comparator<OrdersHolder>() {
            @Override
            public int compare(OrdersHolder o1, OrdersHolder o2) {
                if (o1.isCancelledOrExecuted() && !o2.isCancelledOrExecuted()) {
                    return -1;
                } else if (!o1.isCancelledOrExecuted() && o2.isCancelledOrExecuted()) {
                    return 1;
                } else {
                    return o2.getClientOrder().getPrice().compareTo(o1.getClientOrder().getPrice()) * (getSide() == PositionSide.SHORT ? -1 : 1);
                }
            }
        });
        return sortedReversal;
    }

    @Deprecated
    public void setOrdersHoldersTest(ArrayList<OrdersHolder> test) {
        this.orders = test;
    }

    public List<OrdersHolder> getOrdersSorted() {
        ArrayList<OrdersHolder> sorted = new ArrayList<>(orders);
        Collections.sort(sorted, new Comparator<OrdersHolder>() {
            @Override
            public int compare(OrdersHolder o1, OrdersHolder o2) {
                if (o1.isCancelledOrExecuted() && !o2.isCancelledOrExecuted()) {
                    return 1;
                } else if (!o1.isCancelledOrExecuted() && o2.isCancelledOrExecuted()) {
                    return -1;
                } else if (o1.isCancelled() && !o2.isCancelled()) {
                    return 1;
                } else if (!o1.isCancelled() && o2.isCancelled()) {
                    return -1;
                } else if (o1.isExecuted() && !o2.isExecuted()) {
                    return 1;
                } else if (!o1.isExecuted() && o2.isExecuted()) {
                    return -1;
                } else {
                    return o1.getClientOrder().getPrice().compareTo(o2.getClientOrder().getPrice()) * (getSide() == PositionSide.SHORT ? -1 : 1);
                }
            }
        });
        return sorted;
    }

    public List<OrdersHolder> getOrders() {
        return orders;
    }

    public boolean updateOrder(Order orderUpdate) {
        for (OrdersHolder ordersHolder : orders) {
            if (ordersHolder.getClientOrder().getNewClientOrderId().equals(orderUpdate.getClientOrderId())) {
                ordersHolder.setEntryPrice(this.entryPrice);
                ordersHolder.setServerOrder(orderUpdate);
                if (OrderStatus.FILLED.equals(orderUpdate.getOrderStatus())) {
                    ordersHolder.setExecuted(true);
                } else if (OrderStatus.CANCELED.equals(orderUpdate.getOrderStatus())) {
                    ordersHolder.setCancelled(true);
                }
                return true;
            }
        }
        return false;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getEntryPrice() {
        return entryPrice;
    }

    public void setEntryPrice(String entryPrice) {
        this.entryPrice = entryPrice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE)
                .append(" amount", amount)
                .append(" entryPrice", entryPrice)
                .toString();
    }

}
