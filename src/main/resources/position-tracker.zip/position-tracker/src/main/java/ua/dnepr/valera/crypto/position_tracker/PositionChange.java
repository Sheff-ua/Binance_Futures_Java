package ua.dnepr.valera.crypto.position_tracker;

public enum PositionChange {
    OPEN,
    CLOSE,
    INCREASE,
    DECREASE,
    NOTHING, // maybe just new limit order is placed
    INVERSION_TO_BUY,
    INVERSION_TO_SELL
}
