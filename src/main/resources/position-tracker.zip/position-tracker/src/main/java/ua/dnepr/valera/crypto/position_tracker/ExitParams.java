package ua.dnepr.valera.crypto.position_tracker;

public class ExitParams {

    private ExitPolicy policy = ExitPolicy.ASAP;

    private int parts;
    private double pointsOfProfit;

    private boolean trailing;
    private double pointsOfTrailing;

    private boolean stopLoss;
    private double pointsOfLoss;

    public ExitPolicy getPolicy() {
        return policy;
    }

    public void setPolicy(ExitPolicy policy) {
        this.policy = policy;
    }

    public int getParts() {
        return parts;
    }

    public void setParts(int parts) {
        this.parts = parts;
    }

    public double getPointsOfProfit() {
        return pointsOfProfit;
    }

    public void setPointsOfProfit(double pointsOfProfit) {
        this.pointsOfProfit = pointsOfProfit;
    }

    public boolean isTrailing() {
        return trailing;
    }

    public void setTrailing(boolean trailing) {
        this.trailing = trailing;
    }

    public double getPointsOfTrailing() {
        return pointsOfTrailing;
    }

    public void setPointsOfTrailing(double pointsOfTrailing) {
        this.pointsOfTrailing = pointsOfTrailing;
    }

    public boolean isStopLoss() {
        return stopLoss;
    }

    public void setStopLoss(boolean stopLoss) {
        this.stopLoss = stopLoss;
    }

    public double getPointsOfLoss() {
        return pointsOfLoss;
    }

    public void setPointsOfLoss(double pointsOfLoss) {
        this.pointsOfLoss = pointsOfLoss;
    }
}
