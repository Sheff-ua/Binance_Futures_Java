package ua.dnepr.valera.crypto.position_tracker;

public enum OrderChange {
}
