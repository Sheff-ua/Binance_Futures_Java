package ua.dnepr.valera.crypto.position_tracker;

import com.binance.fapi.client.domain.OrderSide;
import com.binance.fapi.client.domain.account.NewOrder;
import com.binance.fapi.client.domain.account.Position;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {

        PositionState curr = new PositionState();
        curr.setAmount("-0.001");
        Position posUpd = new Position();
        posUpd.setAmount("-0.002");
        TestBinanceFuturesAPI.detectPositionChange(curr, posUpd);

        String price = "8465.7634";
        System.out.println(price + " --->>>  " + TestBinanceFuturesAPI.toDecimal(price).setScale(TestBinanceFuturesAPI.PRICE_PRECISION, RoundingMode.DOWN));

        String amount = "10";
        System.out.println(amount);
        List<NewOrder> orders000 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders000) {
            System.out.println(order);
        }

        amount = "1";
        System.out.println(amount);
        List<NewOrder> orders00 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders00) {
            System.out.println(order);
        }

        amount = "0.1";
        System.out.println(amount);
        List<NewOrder> orders0 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders0) {
            System.out.println(order);
        }

        amount = "0.01";
        System.out.println(amount);
        List<NewOrder> orders = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders) {
            System.out.println(order);
        }

        amount = "0.002";
        System.out.println(amount);
        List<NewOrder> orders2 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders2) {
            System.out.println(order);
        }

        amount = "0.001";
        System.out.println(amount);
        List<NewOrder> orders3 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 3, 2, 0);
        for (NewOrder order : orders3) {
            System.out.println(order);
        }

        amount = "-0.062";
        System.out.println(amount);
        List<NewOrder> orders4 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8805.999"), 2, 8, 10);
        for (NewOrder order : orders4) {
            System.out.println(order);
        }

//        CurrentPosition: PositionState[ amount=-0.7, entryPrice=8475.31428]
//        2019.11.15 17:24:30.946 Placing order async: NewOrder[side=BUY,type=LIMIT,price=8470.42,quantity=0.174,newClientOrderId=VK-102-37--1573831470946,symbol=BTCUSDT,timeInForce=GTC,stopPrice=<null>]
//        2019.11.15 17:24:30.946 Placing order async: NewOrder[side=BUY,type=LIMIT,price=8468.92,quantity=0.174,newClientOrderId=VK-102-38--1573831470946,symbol=BTCUSDT,timeInForce=GTC,stopPrice=<null>]
//        2019.11.15 17:24:30.946 Placing order async: NewOrder[side=BUY,type=LIMIT,price=8467.42,quantity=0.174,newClientOrderId=VK-102-39--1573831470946,symbol=BTCUSDT,timeInForce=GTC,stopPrice=<null>]
//        2019.11.15 17:24:30.946 Placing order async: NewOrder[side=BUY,type=LIMIT,price=8465.92,quantity=0.177,newClientOrderId=VK-102-40--1573831470946,symbol=BTCUSDT,timeInForce=GTC,stopPrice=<null>]

        amount = "-0.7";
        System.out.println(amount);
        List<NewOrder> orders5 = TestBinanceFuturesAPI.createProfitOrdersList(TestBinanceFuturesAPI.toDecimal(amount), TestBinanceFuturesAPI.toDecimal("8475.31428"), 4, 6, 36);
        for (NewOrder order : orders5) {
            System.out.println(order);
        }

        PositionState ps = new PositionState();
        ps.setAmount("-1");
        ArrayList<OrdersHolder> ohList = new ArrayList<>();
        NewOrder co;
        OrdersHolder oh;
        String entryPrice = "8787.87";
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8756.75");
        oh = new OrdersHolder(co, entryPrice);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8754.5");
        oh = new OrdersHolder(co, entryPrice);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8762.75");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8762.5");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8762.0");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8762.0");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8761.25");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8761.25");
        oh = new OrdersHolder(co, entryPrice);
        oh.setExecuted(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8760.5");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8760.5");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8759.0");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8759.0");
        oh = new OrdersHolder(co, entryPrice);
        oh.setExecuted(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8757.5");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);
        co = new NewOrder("", OrderSide.BUY, null, null, null, "8757.5");
        oh = new OrdersHolder(co, entryPrice);
        oh.setCancelled(true);
        ohList.add(oh);



        ps.setOrdersHoldersTest(ohList);

        for (OrdersHolder oh1 : ps.getOrdersSorted()) {
            System.out.println(oh1);
        }


    }
}
