package ua.dnepr.valera.crypto.position_tracker;

import java.math.BigDecimal;

public class Test2 {
    public static void main(String[] args) {

        BigDecimal cur = new BigDecimal(1);
        BigDecimal updated = new BigDecimal(2);

        System.out.println(updated.subtract(cur));


    }
}
