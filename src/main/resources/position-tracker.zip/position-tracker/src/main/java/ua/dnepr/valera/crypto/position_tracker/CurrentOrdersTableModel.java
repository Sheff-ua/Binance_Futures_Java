package ua.dnepr.valera.crypto.position_tracker;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class CurrentOrdersTableModel extends AbstractTableModel {
    private String[] columnNames = {"Price", "Amount", "Filled", "Profit", "Order Label", "Is Executed"};
    private ArrayList<ArrayList<Object>> data = new ArrayList<>();

    public CurrentOrdersTableModel() {

    }

    public CurrentOrdersTableModel(ArrayList<ArrayList<Object>> data) {
        this.data = data;
    }

    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
        if (data.size() > 0) {
            return data.get(row).get(col);
        } else{
            return null;
        }

    }

    public Class getColumnClass(int c) {
        if (data.size() > 0) {
            return getValueAt(0, c).getClass();
        } else {
            return String.class;
        }
    }

    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {
        return false;
    }

    /*
     * Don't need to implement this method unless your table's
     * data can change.
     */
    public void setValueAt(Object value, int row, int col) {
        if (data.size() > 0) {
            data.get(row).set(col, value);
            fireTableCellUpdated(row, col);
        }
    }


//
//    public void setData(ArrayList<ArrayList<Object>> data) {
//        this.data = data;
//        fireTableDataChanged();
//    }

}
