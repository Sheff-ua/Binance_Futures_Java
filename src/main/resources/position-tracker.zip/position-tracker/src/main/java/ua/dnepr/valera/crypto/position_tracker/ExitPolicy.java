package ua.dnepr.valera.crypto.position_tracker;

public enum ExitPolicy {

    HODL,
    ASAP

    // trailing last part
    // stop loss v Bezubitok

}
