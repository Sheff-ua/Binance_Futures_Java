package ua.dnepr.valera.crypto.position_tracker;

import com.binance.fapi.client.*;
import com.binance.fapi.client.domain.OrderSide;
import com.binance.fapi.client.domain.OrderStatus;
import com.binance.fapi.client.domain.OrderType;
import com.binance.fapi.client.domain.TimeInForce;
import com.binance.fapi.client.domain.account.*;
import com.binance.fapi.client.domain.account.request.CancelOrderRequest;
import com.binance.fapi.client.domain.account.request.OrderRequest;
import com.binance.fapi.client.domain.event.AccountUpdateEvent;
import com.binance.fapi.client.domain.event.OrderTradeUpdateEvent;
import com.binance.fapi.client.domain.event.UserDataUpdateEvent;
import com.binance.fapi.client.exception.BinanceApiException;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.Timer;

class TestBinanceFuturesAPI {

    public static final String SYMBOL = "BTCUSDT";
    public static final int AMOUNT_PRECISION = 3;
    public static final int PRICE_PRECISION = 2;
    public static final BigDecimal MIN_ORDER_AMOUNT = new BigDecimal("0.001");
    public static final BigDecimal MIN_ORDER_PRICE = new BigDecimal("0.01");

    private static final DateFormat formatter = new SimpleDateFormat("YYYY.MM.dd HH:mm:ss.SSS"); // "YYYY.MM.dd HH:mm:ss SSS (X)"
    private static final NumberFormat priceFormat = DecimalFormat.getInstance(Locale.ROOT);
    private static final NumberFormat amountFormat = DecimalFormat.getInstance(Locale.ROOT);


    private static long sequence = 100;

    private static BinanceApiAsyncRestClient asyncClient;
    private static BinanceApiRestClient syncClient;
    private static BinanceApiWebSocketClient webSocketClient;
    private static Timer keepAliveTimer;
    private static Timer positionObserverTimer;


    private static PositionState currentPosition;
    private static ExitParams exitParams;
    private static JTable ordersTable;

    private static JLabel currentSideLabel = new JLabel("---");
    private static JLabel currentEntryPriceLabel = new JLabel("0");
    private static JLabel currentAmountLabel = new JLabel("0");
    private static JLabel tpOrdersAmountLabel = new JLabel("0");
    private static JLabel lastCommissionLabel = new JLabel("0");

    private static JLabel currentPnLLabel = new JLabel("TODO"); // market streams should be implemented in order to get last ask/bid

    private static DefaultTableCellRenderer defaultRenderer;
    private static DefaultTableCellRenderer centerRenderer;

    static {
        priceFormat.setMaximumFractionDigits(2);
        priceFormat.setMinimumFractionDigits(2);
        priceFormat.setGroupingUsed(false);

        amountFormat.setMaximumFractionDigits(3);
        amountFormat.setMinimumFractionDigits(3);
        amountFormat.setGroupingUsed(false);
    }


    public static BigDecimal toDecimal(String amount) {
        if (amount == null) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(amount);
    }

    public static String formatPrice(BigDecimal price) {
        synchronized (priceFormat) {
            return priceFormat.format(price);
        }
    }

    public static String formatAmount(BigDecimal amount) {
        synchronized (amountFormat) {
            return amountFormat.format(amount);
        }
    }

    public static synchronized String formatDate(long timeInMillis) {
        return formatter.format(new Date(timeInMillis));
    }


    public static List<NewOrder> createProfitOrdersList(BigDecimal amount, BigDecimal entryPrice, int parts, double points, int proceedOrderSeq) {
        List<NewOrder> result = new ArrayList<>();
        long timestamp = System.currentTimeMillis();

        //BigDecimal amountDecimal = new BigDecimal(amount, AMOUNT_MC).setScale(AMOUNT_PRECISION, RoundingMode.UP);
        if (BigDecimal.ZERO.compareTo(amount) == 0) {
            return result;
        }
        int signum = amount.signum(); // -1.0, 0, 1.0
        amount = amount.abs();
        //BigDecimal amountDecimal = new BigDecimal(Math.abs(amount), AMOUNT_MC).setScale(AMOUNT_PRECISION, RoundingMode.UP);

        BigDecimal amountPart = amount.divide(new BigDecimal(parts), AMOUNT_PRECISION, RoundingMode.DOWN);

        double commission = (entryPrice.doubleValue() * (0.03 / 100.0f)) * 2; // TODO BigDecimal for commission
        //System.out.println("Commission: " + commission);

        BigDecimal amountPartsSum = BigDecimal.ZERO;

        for (int i = 1; i <= parts; i++) {
            BigDecimal amountToSet = amountPart;
            if (i != parts) {
                amountPartsSum = amountPartsSum.add(amountPart);
            } else { // last iteration
                amountToSet = amount.subtract(amountPartsSum);

            }
            if (amountToSet.compareTo(MIN_ORDER_AMOUNT) < 0) {  // small orders defense
                amountPartsSum = amountPartsSum.subtract(amountPart);
                continue;
            }
            double priceDelta = (commission + (points / parts) * i) * (signum > 0 ? 1 : -1);

            String priceToSet = formatPrice(new BigDecimal(entryPrice.doubleValue() + priceDelta));
            NewOrder order = new NewOrder(SYMBOL, (signum > 0 ? OrderSide.SELL : OrderSide.BUY), OrderType.LIMIT, TimeInForce.GTC,
                    String.valueOf(amountToSet),
                    priceToSet);
            order.setNewClientOrderId("VK-" + sequence + "-" + (proceedOrderSeq + i) + "--" + timestamp);
            order.setNewClientOrderIdLabel("VK-" + sequence + "-" + (proceedOrderSeq + i));
            order.setReduceOnly("true");
            result.add(order);
        }
        return result;
    }

    public static void placeOrdersAsync(BinanceApiAsyncRestClient asyncRestClient, List<NewOrder> orders) {
        for (NewOrder order : orders) {
            System.out.println(formatDate(System.currentTimeMillis()) + " Placing order async: " + order);
            asyncRestClient.newOrder(order, new BinanceApiCallback<NewOrderResponse>() {
                @Override
                public void onResponse(NewOrderResponse response) {
                    //System.out.println("New Order response received: " + response);
                }

                @Override
                public void onFailure(Throwable cause) {
                    // TODO sync created/not created orders with currentPosition.orders
                    System.out.println("Error occurred during New Order placement: " + cause);
                }
            });
        }
    }

    public static void cancelAllOrdersSync(PositionState currentPosition) {
        List<OrdersHolder> orders = currentPosition.getOrdersSortedReversal();
        cancelOrdersSync(orders);
    }

    public static void cancelOrdersSync(List<OrdersHolder> orders) {
        for (OrdersHolder order : orders) {
            if (!order.isCancelledOrExecuted()) {
                CancelOrderRequest cancelOrderRequest = new CancelOrderRequest(SYMBOL, order.getClientOrder().getNewClientOrderId());
                try {
                    System.out.println(formatDate(System.currentTimeMillis()) + " Cancelling Order sync: " + cancelOrderRequest);
                    syncClient.cancelOrder(cancelOrderRequest);
                } catch (BinanceApiException be) {
                    if ("Unknown order sent".equals(be.getMessage())) {
                        System.out.println("Tried to cancel already cancelled or executed order");
                    }
                } catch (Throwable cause) {
                    System.out.println("Some error occurred during Order cancel: " + cause);
                }
                // TODO distinct cancel requested and actual cancel
                order.setCancelled(true);
            }
        }
    }

    public static void refreshTableModel(PositionState currentPosition) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ordersTable.setModel(createTableModel(currentPosition));
                ordersTable.getColumnModel().getColumn(0).setCellRenderer(defaultRenderer);
                ordersTable.getColumnModel().getColumn(1).setCellRenderer(defaultRenderer);
                ordersTable.getColumnModel().getColumn(2).setCellRenderer(defaultRenderer);
                ordersTable.getColumnModel().getColumn(3).setCellRenderer(defaultRenderer);
                ordersTable.getColumnModel().getColumn(4).setCellRenderer(defaultRenderer);
                ordersTable.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
            }
        });
    }

    public static BigDecimal calcTpOrderAmount(PositionState currentPosition) {
        BigDecimal amountSum = BigDecimal.ZERO;
        //double amountSum = 0;
        for (OrdersHolder ordersHolder : currentPosition.getOrdersSorted()) {
            if (!ordersHolder.isCancelledOrExecuted()) {
                if (ordersHolder.getServerOrder() == null) {
                    // FIXME BigDecimal here and
                    amountSum = amountSum.add(OrderSide.BUY.equals(ordersHolder.getClientOrder().getSide())
                            ? toDecimal(ordersHolder.getClientOrder().getQuantity()).negate()
                            : toDecimal(ordersHolder.getClientOrder().getQuantity()));
                    //amountSum += Double.valueOf(ordersHolder.getClientOrder().getQuantity()) * (OrderSide.BUY.equals(ordersHolder.getClientOrder().getSide()) ? -1 : 1);
                } else {
                    amountSum = amountSum.add(OrderSide.BUY.equals(ordersHolder.getServerOrder().getSide())
                            ? toDecimal(ordersHolder.getServerOrder().getOriginalQuantity()).subtract(toDecimal(ordersHolder.getServerOrder().getAccumulatedQuantity())).negate()
                            : toDecimal(ordersHolder.getServerOrder().getOriginalQuantity()).subtract(toDecimal(ordersHolder.getServerOrder().getAccumulatedQuantity())));
                    //amountSum += Double.valueOf(ordersHolder.getServerOrder().getOriginalQuantity()) * (OrderSide.BUY.equals(ordersHolder.getServerOrder().getSide()) ? -1 : 1);
                }
            }
        }
        return amountSum;
    }

    public static PositionState loadPositionState(PositionInfo positionInfo) {
        PositionState positionState = new PositionState();
        positionState.setAmount(positionInfo.getAmount());
        positionState.setEntryPrice(positionInfo.getEntryPrice());
        return positionState;
    }

//    public static PositionState loadPositionState(Position positionUpdate) {
//        PositionState positionState = new PositionState();
//        positionState.setAmount(positionUpdate.getAmountDouble());
//        positionState.setEntryPrice(positionUpdate.getEntryPriceDouble());
//        return positionState;
//    }

    public static void loadOrdersToPositionState(PositionState positionState) {
        List<ServerOrder> serverOrders = syncClient.getOpenOrders(new OrderRequest(SYMBOL));
        System.out.println("Found Server orders: " + serverOrders);
        positionState.setServerOrders(serverOrders);
    }

    public static PositionChange detectPositionChange(PositionState currPosition, Position positionUpdate) {
        if (positionUpdate == null || (currPosition.isOpen() && !positionUpdate.isOpen())) {
            return PositionChange.CLOSE;
        } else if (!currPosition.isOpen() && positionUpdate.isOpen()) {
            return PositionChange.OPEN;
        }

        if (!currPosition.isOpen() && !positionUpdate.isOpen()) {
            return PositionChange.NOTHING;
        }
        if (currPosition.isOpen() && positionUpdate.isOpen() && toDecimal(currPosition.getAmount()).compareTo(toDecimal(positionUpdate.getAmount())) == 0) {
            return PositionChange.NOTHING;
        }

        // swing case
        if (toDecimal(currPosition.getAmount()).compareTo(BigDecimal.ZERO) > 0 && toDecimal(positionUpdate.getAmount()).compareTo(BigDecimal.ZERO) < 0) {
            return PositionChange.INVERSION_TO_SELL;
        }
        if (toDecimal(currPosition.getAmount()).compareTo(BigDecimal.ZERO) < 0 && toDecimal(positionUpdate.getAmount()).compareTo(BigDecimal.ZERO) > 0) {
            return PositionChange.INVERSION_TO_BUY;
        }

        // open && open case
        if (toDecimal(currPosition.getAmount()).abs().compareTo(toDecimal(positionUpdate.getAmount()).abs()) > 0) {
            return PositionChange.DECREASE;
        }

        if (toDecimal(currPosition.getAmount()).abs().compareTo(toDecimal(positionUpdate.getAmount()).abs()) < 0) {
            return PositionChange.INCREASE;
        }

        return null;
    }

    public static CurrentOrdersTableModel createTableModel(PositionState currentPosition) {
        ArrayList<ArrayList<Object>> data = new ArrayList<ArrayList<Object>>();
        for (OrdersHolder ordersHolder : currentPosition.getOrdersSorted()) {
            ArrayList<Object> row = new ArrayList<Object>();

            // Entry price
            row.add(ordersHolder.getClientOrder().getPrice());

            // Amount
            if (ordersHolder.getServerOrder() == null) {
                row.add(ordersHolder.getClientOrder().getQuantity());
            } else {
                row.add(ordersHolder.getServerOrder().getOriginalQuantity());
            }

            // Filled
            if (ordersHolder.getServerOrder() == null) {
                row.add("0");
            } else {
                row.add(ordersHolder.getServerOrder().getAccumulatedQuantity());
            }

            // TODO calculate profit in USDT
            // Profit
            if (ordersHolder.getServerOrder() == null) {
                row.add("0");
            } else if (ordersHolder.getServerOrder().getOrderStatus() == OrderStatus.FILLED || ordersHolder.getServerOrder().getOrderStatus() == OrderStatus.PARTIALLY_FILLED
                    || (ordersHolder.getServerOrder().getOrderStatus() == OrderStatus.CANCELED && toDecimal(ordersHolder.getServerOrder().getAccumulatedQuantity()).compareTo(BigDecimal.ZERO) > 0)) {

                BigDecimal price = toDecimal(ordersHolder.getServerOrder().getLastFilledPrice());

                row.add((PositionSide.LONG.equals(currentPosition.getSide()) ?
                        formatPrice(price.subtract(toDecimal(ordersHolder.getEntryPrice()))) :
                        formatPrice(toDecimal(ordersHolder.getEntryPrice()).subtract(price))) + " pts");
            } else {
                row.add("0");
            }

            // Order Label
            row.add(ordersHolder.getClientOrder().getNewClientOrderIdLabel());

            // Is Executed / Cancelled
            if (ordersHolder.isExecuted() || (ordersHolder.getServerOrder() != null && ordersHolder.getServerOrder().getOrderStatus() == OrderStatus.FILLED)) {
                row.add("+");
            } else if (ordersHolder.isCancelled() || (ordersHolder.getServerOrder() != null && ordersHolder.getServerOrder().getOrderStatus() == OrderStatus.CANCELED)) {
                row.add(" "); // one plus sign less
            } else {
                row.add("");
            }

            data.add(row);
        }
        return new CurrentOrdersTableModel(data);
    }

    public static void refreshCurrentPositionLabels(PositionState currentPosition) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (currentPosition.getSide() == null) {
                    currentSideLabel.setText("---");
                    currentSideLabel.setForeground(Color.LIGHT_GRAY);
                } else {
                    currentSideLabel.setText(currentPosition.getSide().toString());
                    if (PositionSide.LONG.equals(currentPosition.getSide())) {
                        currentSideLabel.setForeground(Color.GREEN);
                    } else {
                        currentSideLabel.setForeground(Color.RED);
                    }
                }
                currentEntryPriceLabel.setText(formatPrice(toDecimal(currentPosition.getEntryPrice())));
                currentAmountLabel.setText(currentPosition.getAmount());

                tpOrdersAmountLabel.setText(formatAmount(calcTpOrderAmount(currentPosition))); // TODO check double/String conversion


                BigDecimal commissionPercents = new BigDecimal(0.06 / 100.0f);
                lastCommissionLabel.setText(toDecimal(currentPosition.getEntryPrice()).multiply(commissionPercents).setScale(PRICE_PRECISION, RoundingMode.DOWN).toString()); // TODO format
                //currentPnLLabel.setText();
            }
        });
    }

    public static void main(String args[]) {
        //Creating the Frame
        JFrame frame = new JFrame("Futures API");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1320, 350);
        //frame.setLocation(1715, 300); // right center part
        frame.setLocation(0, 0); // left up part

        JPanel upsidePanel = new JPanel();
        GridLayout upsideGridLayout = new GridLayout(2, 1);
        upsidePanel.setLayout(upsideGridLayout);

        JPanel upsidePanel1 = new JPanel();
        JLabel label;
        label = new JLabel("Side: ");
        Font font = label.getFont();
        label.setFont(font.deriveFont(font.getStyle() & ~Font.BOLD));
        upsidePanel1.add(label);
        upsidePanel1.add(currentSideLabel);

        label = new JLabel("Entry Price: ");
        label.setFont(font.deriveFont(font.getStyle() & ~Font.BOLD));
        upsidePanel1.add(label);
        currentEntryPriceLabel.setFont(font.deriveFont(font.getStyle() | Font.BOLD));
        upsidePanel1.add(currentEntryPriceLabel);

        label = new JLabel("Amount: ");
        upsidePanel1.add(label);
        label.setFont(font.deriveFont(font.getStyle() & ~Font.BOLD));
        upsidePanel1.add(currentAmountLabel);

        label = new JLabel("TP Amount Sum: ");
        upsidePanel1.add(label);
        label.setFont(font.deriveFont(font.getStyle() & ~Font.BOLD));
        upsidePanel1.add(tpOrdersAmountLabel);

        label = new JLabel("   Commission: ");
        upsidePanel1.add(label);
        label.setFont(font.deriveFont(font.getStyle() & ~Font.BOLD));
        upsidePanel1.add(lastCommissionLabel);

        JPanel upsidePanel2 = new JPanel();
        JSlider partsSlider = new JSlider(1, 5, 1);
        partsSlider.setMajorTickSpacing(1);
        partsSlider.setMinorTickSpacing(1);
        partsSlider.setPaintTicks(true);
        Hashtable partsLabels = new Hashtable();
        partsLabels.put(1, new JLabel("1"));
        partsLabels.put(2, new JLabel("2"));
        partsLabels.put(3, new JLabel("3"));
        partsLabels.put(4, new JLabel("4"));
        partsLabels.put(5, new JLabel("5"));
        partsSlider.setLabelTable(partsLabels);
        partsSlider.setPaintLabels(true);

        JSlider pointsSlider = new JSlider(-20, 100, 5);
        pointsSlider.setPreferredSize(new Dimension(500, 50));
        pointsSlider.setMajorTickSpacing(5);
        pointsSlider.setMinorTickSpacing(1);
        pointsSlider.setPaintTicks(true);
        Hashtable pointsLabels = new Hashtable();
        pointsLabels.put(-20, new JLabel("-20"));
        pointsLabels.put(-10, new JLabel("-10"));
        pointsLabels.put(-5, new JLabel("-5"));
        pointsLabels.put(0, new JLabel("0"));
        pointsLabels.put(5, new JLabel("5"));
        pointsLabels.put(10, new JLabel("10"));
        pointsLabels.put(15, new JLabel("15"));
        pointsLabels.put(20, new JLabel("20"));
        pointsLabels.put(25, new JLabel("25"));
        pointsLabels.put(30, new JLabel("30"));
        pointsLabels.put(50, new JLabel("50"));
        pointsLabels.put(100, new JLabel("100"));
        pointsSlider.setLabelTable(pointsLabels);
        pointsSlider.setPaintLabels(true);

        JButton applyChanges = new JButton("Apply");

        upsidePanel2.add(partsSlider);
        upsidePanel2.add(pointsSlider);
        upsidePanel2.add(applyChanges);



        // Table at the Center
        CurrentOrdersTableModel ordersTableModel = new CurrentOrdersTableModel();
        ordersTable = new JTable(ordersTableModel);
        JScrollPane centerScrollPane = new JScrollPane(ordersTable);

        defaultRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String status = ((String)table.getValueAt(row, 5));
                c.setBackground(status != null && !status.isEmpty() ? Color.LIGHT_GRAY : Color.WHITE);
                return c;
            }
        };

        centerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String status = ((String)table.getValueAt(row, 5));
                c.setBackground(status != null && !status.isEmpty() ? Color.LIGHT_GRAY : Color.WHITE);
                return c;
            }
        };
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);



        //Creating the panel at bottom and adding components
        JPanel downsidePanel = new JPanel(); // the panel is not visible in output
        //Adding Components to the frame.
        upsidePanel.add(upsidePanel1);
        upsidePanel.add(upsidePanel2);
        frame.getContentPane().add(BorderLayout.NORTH, upsidePanel);
        frame.getContentPane().add(BorderLayout.CENTER, centerScrollPane);
        frame.getContentPane().add(BorderLayout.SOUTH, downsidePanel);
        frame.setVisible(true);


        exitParams = new ExitParams();
        exitParams.setParts(partsSlider.getValue());
        exitParams.setPointsOfProfit(pointsSlider.getValue());


        // Creating Factory and Clients
        BinanceApiClientFactory factory = BinanceApiClientFactory.newInstance(
                "LbHeMTomG9EcalhKfpGz1S00zTx8RAwSC7G3xCCiZh98q2cLde9A8AV3l3b6NLZA",
                "KVs5vZYSmyZZrZf2jxaGhBBi8iNb2FHedT604GaIAM1MNLCL1FM9hyWeCrmVGHg0"
        );

        asyncClient = factory.newAsyncRestClient();
        syncClient = factory.newRestClient();

        List<PositionInfo> positions = null;
        while (true) {
            try {
                positions = syncClient.getPositionInfos();
            } catch (BinanceApiException be) {
                System.out.println(formatDate(System.currentTimeMillis()) + "  " + be);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (positions != null) {
                break;
            }
        }

        currentPosition = loadPositionState(positions.get(0));
        System.out.println("CurrentPosition: " + currentPosition);

        loadOrdersToPositionState(currentPosition);
        refreshTableModel(currentPosition);
        refreshCurrentPositionLabels(currentPosition);


        // First, we obtain a listenKey which is required to interact with the user data stream
        String listenKey = syncClient.startUserDataStream();

        // Then, we open a new web socket client, and provide a callback that is called on every update
        webSocketClient = factory.newWebSocketClient();


        // Listen for changes in the account
        webSocketClient.onUserDataUpdateEvent(listenKey, new BinanceApiCallback<UserDataUpdateEvent>() { // FIXME this is an event loop. Code inside should be async if possible
            @Override
            public void onResponse(UserDataUpdateEvent response) {
                switch (response.getEventType()) {
                    case ACCOUNT_UPDATE:
                        AccountUpdateEvent accountUpdateEvent = response.getAccountUpdateEvent();

                        System.out.println(formatDate(System.currentTimeMillis()) + "  " + response.getEventType() + " " + accountUpdateEvent.getFuturesAccount());
                        Position positionUpdate = accountUpdateEvent.getFuturesAccount().getPositions().size() > 0 ? accountUpdateEvent.getFuturesAccount().getPositions().get(0) : null;
                        PositionChange positionChange = detectPositionChange(currentPosition, positionUpdate);
                        System.out.println(formatDate(System.currentTimeMillis()) + " Detected PositionChange: " + positionChange);

                        if (positionChange != null) {
                            switch (positionChange) {
                                case OPEN:
                                    // place orders and store them in PositionState
                                    List<NewOrder> takeProfitOrders = createProfitOrdersList(toDecimal(positionUpdate.getAmount()), toDecimal(positionUpdate.getEntryPrice()),
                                            exitParams.getParts(), exitParams.getPointsOfProfit(), 0);
                                    placeOrdersAsync(asyncClient, takeProfitOrders);

                                    // store currentPosition
                                    currentPosition.setAmount(positionUpdate.getAmount());
                                    currentPosition.setEntryPrice(positionUpdate.getEntryPrice());
                                    currentPosition.setOrders(takeProfitOrders);

                                    refreshTableModel(currentPosition);
                                    refreshCurrentPositionLabels(currentPosition);

                                    break;
                                case INCREASE:
                                    // additional amount with the same or worse price arrived. No need to recreate existing Take Profit orders
                                    // TODO
                                    if ((PositionSide.LONG.equals(currentPosition.getSide()) && toDecimal(positionUpdate.getEntryPrice()).compareTo(toDecimal(currentPosition.getEntryPrice())) >= 0) ||
                                            (PositionSide.SHORT.equals(currentPosition.getSide()) && toDecimal(positionUpdate.getEntryPrice()).compareTo(toDecimal(currentPosition.getEntryPrice())) <= 0)) {

                                        System.out.println(formatDate(System.currentTimeMillis()) + " Just additional amount");

                                        BigDecimal freshAmountAbs = toDecimal(positionUpdate.getAmount()).abs().subtract(toDecimal(currentPosition.getAmount()).abs());
                                        BigDecimal freshAmount = PositionSide.LONG.equals(currentPosition.getSide()) ? freshAmountAbs : freshAmountAbs.negate();

                                        List<NewOrder> takeProfitOrdersIncr = createProfitOrdersList(freshAmount, toDecimal(positionUpdate.getEntryPrice()),
                                                exitParams.getParts(), exitParams.getPointsOfProfit(), currentPosition.getOrders().size());
                                        placeOrdersAsync(asyncClient, takeProfitOrdersIncr);

                                        currentPosition.setAmount(positionUpdate.getAmount());
                                        currentPosition.setEntryPrice(positionUpdate.getEntryPrice());
                                        currentPosition.addOrders(takeProfitOrdersIncr);

                                        refreshTableModel(currentPosition);
                                        refreshCurrentPositionLabels(currentPosition);

                                    } else { // usrednenie (additional amount with better price arrived)
                                        // TODO Cancel existing orders and place new with fresh ExitParams
                                        System.out.println(formatDate(System.currentTimeMillis()) + " !!!!!!!!!! Usrednenie TEMPORALLY implemented !!!!!!!!!!");

                                        List<NewOrder> takeProfitOrdersIncr = createProfitOrdersList(toDecimal(positionUpdate.getAmount()), toDecimal(positionUpdate.getEntryPrice()),
                                                exitParams.getParts(), exitParams.getPointsOfProfit(), currentPosition.getOrders().size());
                                        placeOrdersAsync(asyncClient, takeProfitOrdersIncr);

                                        currentPosition.setAmount(positionUpdate.getAmount());
                                        currentPosition.setEntryPrice(positionUpdate.getEntryPrice());
                                        currentPosition.addOrders(takeProfitOrdersIncr);

                                        refreshTableModel(currentPosition);
                                        refreshCurrentPositionLabels(currentPosition);




//                                        // 0) remember orders that should be recreated
//                                        // 1) create new orders for new amount with fresh ExitParams -- async
//                                        // 2) cancel old orders -- sync OR just create new orders with better price and old orders will be removed by exchange?
//                                        // 3) create new orders for old amount with fresh ExitParams -- async (add checkbox that rules usrednenie or not)
//
//                                        // temp START
//
//                                        // 0)
//                                        //List<OrdersHolder> oldOrders = new ArrayList<>(currentPosition.getOrdersSortedReversal());
//                                        //BigDecimal oldAmount = toDecimal(currentPosition.getAmount());
//
//                                        // 1)
//                                        BigDecimal freshAmountAbs = toDecimal(positionUpdate.getAmount()).abs().subtract(toDecimal(currentPosition.getAmount()).abs());
//                                        BigDecimal freshAmount = PositionSide.LONG.equals(currentPosition.getSide()) ? freshAmountAbs : freshAmountAbs.negate(); // add sign to amount
//
//                                        List<NewOrder> takeProfitOrdersIncr = createProfitOrdersList(
//                                                freshAmount,
//                                                toDecimal(positionUpdate.getEntryPrice()),
//                                                exitParams.getParts(), exitParams.getPointsOfProfit(), currentPosition.getOrders().size());
//                                        placeOrdersAsync(asyncClient, takeProfitOrdersIncr);
//
//                                        currentPosition.setAmount(positionUpdate.getAmount());
//                                        currentPosition.setEntryPrice(positionUpdate.getEntryPrice());
//                                        currentPosition.addOrders(takeProfitOrdersIncr);
//
//                                        refreshTableModel(currentPosition);
//                                        refreshCurrentPositionLabels(currentPosition);
//
//
//                                        // 2)
//                                        // TODO check situation when exchange will remove one of the orders replacing it with smaller amount (depending on the profit /parts (especially big profit) it seems  to be possible)
//                                        //cancelOrdersSync(oldOrders);
//
//                                        // temp END

                                    }
                                    break;
                                case DECREASE:
                                    // TODO update current position in order to track situation (fresh amount up to date) when usrednenie is performed but some takeProfit orders already executed
                                    // TODO think how this will work when some intermediate deals on smaller then initial position are performed !!!

                                    currentPosition.setAmount(positionUpdate.getAmount());
                                    currentPosition.setEntryPrice(positionUpdate.getEntryPrice());
                                    refreshCurrentPositionLabels(currentPosition);
                                    break;
                                case CLOSE:
                                    currentPosition.setAmount("0");
                                    currentPosition.setEntryPrice("0.00");
                                    // clear orders and print stats // TODO stats

                                    currentPosition.setOrders(new ArrayList<NewOrder>());

                                    //System.out.println("Setting model with empty data!");
                                    refreshCurrentPositionLabels(currentPosition);
                                    refreshTableModel(currentPosition);
                                    sequence++;
                                    break;
                            }
                        } else {
                            System.out.println(formatDate(System.currentTimeMillis()) + " !!!!!!!!!!!!!!!!!! Something go wrong. Position changed to unknown state !!!!!!!!!!!!!!!!");
                        }

                        break;
                    case ORDER_TRADE_UPDATE:
                        // TODO track created externally orders firstly when position is already opened and new order leads to cancelation of existing tracked orders

                        OrderTradeUpdateEvent orderTradeUpdateEvent = response.getOrderTradeUpdateEvent();
                        System.out.println(formatDate(System.currentTimeMillis()) + "  " + response.getEventType() + " " + orderTradeUpdateEvent.getOrder());
                        Order updatedOrder = orderTradeUpdateEvent.getOrder();
                        boolean oneOfExisting = currentPosition.updateOrder(updatedOrder);
                        if (oneOfExisting) {
                            // TODO process cancelled and executed orders !!!
                            refreshTableModel(currentPosition);
                        } else {
                            System.out.println(formatDate(System.currentTimeMillis()) + " Some unknown or created externally Order");
                        }
                        refreshCurrentPositionLabels(currentPosition);

                        break;
                }
            }

            @Override
            public void onFailure(Throwable cause) {
                System.out.println("**************************************************************************************************************");
                System.out.println(formatDate(System.currentTimeMillis()) + " BinanceApiCallback.onFailure() !!! >> " + cause + " >>> " + cause.getMessage());
                cause.printStackTrace();
                System.out.println("**************************************************************************************************************");
            }
        });

        partsSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                exitParams.setParts(partsSlider.getValue());
            }
        });

        pointsSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                exitParams.setPointsOfProfit(pointsSlider.getValue());
            }
        });

        applyChanges.addActionListener(new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(formatDate(System.currentTimeMillis()) + " Apply clicked. Recreating orders...");

//                if (pointsSlider.getValue() < exitParams.getPointsOfProfit()) { // TODO calc current exit price and calc estimated new exit price then compare
//
//                } else {
//
//                }
                exitParams.setParts(partsSlider.getValue());
                exitParams.setPointsOfProfit(pointsSlider.getValue());


                // TODO if ExitParams changed to lower then place new orders async
                //  (maybe need to compare NewOrder with Order instead of ExitParams to decide)
                //  (need to understand whether existing order will be replaced by the new one automatically because of lower price)
                // TODO if ExitParams changed to higher then place new orders sync


                int oldOrdersSize = currentPosition.getOrders().size();
                // TODO sort in best direction for cancelling (i.e. start cancel from the most far order)
                cancelAllOrdersSync(currentPosition);

// TODO proceed from here
//                for () {
//                    asyncClient.cancelOrder();
//                }


                // TODO track old orders or load remaining + calculate PnL
                //List<OrdersHolder> backupOrders = currentPosition.getOrders();

                List<PositionInfo> positions = syncClient.getPositionInfos();
                if (positions != null && !positions.isEmpty()) {
                    PositionInfo updatedPositionInfo = positions.get(0);
                    currentPosition.setAmount(updatedPositionInfo.getAmount());
                    currentPosition.setEntryPrice(updatedPositionInfo.getEntryPrice());
                    System.out.println("CurrentPosition: " + currentPosition);
                }

                // TODO create fresh orders
                List<NewOrder> takeProfitOrders = createProfitOrdersList(toDecimal(currentPosition.getAmount()), toDecimal(currentPosition.getEntryPrice()),
                        exitParams.getParts(), exitParams.getPointsOfProfit(), oldOrdersSize);
                placeOrdersAsync(asyncClient, takeProfitOrders);

                // store currentPosition
                currentPosition.addOrders(takeProfitOrders);

                refreshCurrentPositionLabels(currentPosition);
                refreshTableModel(currentPosition);
            }
        });




//        positionObserverTimer = new Timer();
//        positionObserverTimer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                // FIXME some synchronization is needed in order to not fall in situation when orders in main loop just started to crate but this Timer already fired !!!!!!!!!
//                List<PositionInfo> positions = syncClient.getPositionInfos();
//                //System.out.println(formatDate(System.currentTimeMillis()) + " Checking for missing amount...");
//                if (positions != null && !positions.isEmpty()) {
//                    PositionInfo updatedPositionInfo = positions.get(0);
//                    BigDecimal currentServerAmount =  toDecimal(updatedPositionInfo.getAmount());
//                    if (!currentServerAmount.equals(BigDecimal.ZERO)) {
//                        BigDecimal currentLocalAmount = calcTpOrderAmount(currentPosition);
//                        if (!currentServerAmount.equals(currentLocalAmount)) {
//                            System.out.println("**************************************************************************************************************");
//                            System.out.println(formatDate(System.currentTimeMillis()) + "Detected difference in Take Profit orders amount. Creating additional order..");
//                            System.out.println("**************************************************************************************************************");
//
//                            BigDecimal missingAmountAbs = currentServerAmount.abs().subtract(currentLocalAmount.abs());
//                            BigDecimal missingAmount = PositionSide.LONG.equals(currentPosition.getSide()) ? missingAmountAbs : missingAmountAbs.negate();
//
//                            // order is created with price a little bit worse in order to prevent rewrite and get exchange synchronization
//                            List<NewOrder> takeProfitOrdersIncr = createProfitOrdersList(missingAmount,
//                                    PositionSide.LONG.equals(currentPosition.getSide()) ? toDecimal(currentPosition.getEntryPrice()).add(MIN_ORDER_PRICE) : toDecimal(currentPosition.getEntryPrice()).subtract(MIN_ORDER_PRICE),
//                                    1, exitParams.getPointsOfProfit(), currentPosition.getOrders().size());
//                            placeOrdersAsync(asyncClient, takeProfitOrdersIncr);
//
//                            // store currentPosition
//                            currentPosition.addOrders(takeProfitOrdersIncr);
//
//                            refreshCurrentPositionLabels(currentPosition);
//                            refreshTableModel(currentPosition);
//                        }
//                    }
//                }
//            }
//        }, (10*1000), (10*1000)); // every 5 seconds after 5 seconds



        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try {
                    // FIXME close or invalidate webstream with user events first in order to prevent "listenKeyExpired"
                    // Or we can invalidate it, whenever it is no longer needed
                    System.out.println(formatDate(System.currentTimeMillis()) + " Sending CloseUserDataStream...");
                    syncClient.closeUserDataStream(listenKey);
                } catch (BinanceApiException be) {
                    System.out.println(formatDate(System.currentTimeMillis()) + " BinanceApiException occurred during stream close. " + be.getMessage());
                }
                e.getWindow().dispose();
                System.out.println(formatDate(System.currentTimeMillis()) + " Application closed!");
            }
        });

        keepAliveTimer = new Timer();
        keepAliveTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                System.out.println(formatDate(System.currentTimeMillis()) + " Sending KeepAliveUserDataStream...");
                syncClient.keepAliveUserDataStream(listenKey);

                // TODO track this here + in stream listener when some action is sent but no response event is received
                //2019.11.18 03:12:38.712 Sending KeepAliveUserDataStream...
                //Exception in thread "Timer-0" com.binance.fapi.client.exception.BinanceApiException: No listen key is found with accountId-22226
                //	at com.binance.fapi.client.impl.BinanceApiServiceGenerator.executeSync(BinanceApiServiceGenerator.java:81)
                //	at com.binance.fapi.client.impl.BinanceApiRestClientImpl.keepAliveUserDataStream(BinanceApiRestClientImpl.java:225)
                //	at ua.dnepr.valera.crypto.position_tracker.TestBinanceFuturesAPI$10.run(TestBinanceFuturesAPI.java:733)
                //	at java.base/java.util.TimerThread.mainLoop(Timer.java:556)
                //	at java.base/java.util.TimerThread.run(Timer.java:506)
            }
        }, (60*25*1000), (60*25*1000)); // every 25 minutes after 25 minutes

    } // #main() END

}
